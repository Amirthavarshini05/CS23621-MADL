package com.example.assignment_02_panandpincodevalidation

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnBasic = findViewById<Button>(R.id.btnBasic)
        val btnMarks = findViewById<Button>(R.id.btnMarks)

        val layoutBasic = findViewById<LinearLayout>(R.id.layoutBasic)
        val layoutMarks = findViewById<LinearLayout>(R.id.layoutMarks)

        btnBasic.setOnClickListener {
            layoutBasic.visibility = View.VISIBLE
            layoutMarks.visibility = View.GONE
        }

        btnMarks.setOnClickListener {
            layoutBasic.visibility = View.GONE
            layoutMarks.visibility = View.VISIBLE
        }
    }
}