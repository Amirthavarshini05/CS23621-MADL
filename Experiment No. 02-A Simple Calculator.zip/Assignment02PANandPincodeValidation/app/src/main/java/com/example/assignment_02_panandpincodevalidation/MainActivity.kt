package com.example.assignment_02_panandpincodevalidation

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val etExpression = findViewById<EditText>(R.id.etExpression)
        val btnCalculate = findViewById<Button>(R.id.btnCalculate)
        val tvResult = findViewById<TextView>(R.id.tvResult)

        btnCalculate.setOnClickListener {
            val expression = etExpression.text.toString()

            // ✅ Validation
            if (expression.isEmpty()) {
                Toast.makeText(this, "Enter expression", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (!isValidExpression(expression)) {
                tvResult.text = "Invalid Expression"
                return@setOnClickListener
            }

            try {
                val result = evaluate(expression)
                tvResult.text = "Result: $result"
            } catch (e: Exception) {
                tvResult.text = "Error"
            }
        }
    }

    // ✅ Basic validation
    private fun isValidExpression(expr: String): Boolean {
        return expr.matches(Regex("^[0-9+\\-*/. ]+$"))
    }

    // ✅ Simple evaluator (supports +, -, *, /)
    private fun evaluate(expr: String): Double {
        val tokens = expr.replace(" ", "")
        val numbers = mutableListOf<Double>()
        val operators = mutableListOf<Char>()

        var num = ""
        for (ch in tokens) {
            if (ch.isDigit() || ch == '.') {
                num += ch
            } else {
                numbers.add(num.toDouble())
                operators.add(ch)
                num = ""
            }
        }
        numbers.add(num.toDouble())

        // First handle * and /
        var i = 0
        while (i < operators.size) {
            if (operators[i] == '*' || operators[i] == '/') {
                val result = if (operators[i] == '*')
                    numbers[i] * numbers[i + 1]
                else
                    numbers[i] / numbers[i + 1]

                numbers[i] = result
                numbers.removeAt(i + 1)
                operators.removeAt(i)
            } else {
                i++
            }
        }

        // Then handle + and -
        var result = numbers[0]
        for (j in operators.indices) {
            result = when (operators[j]) {
                '+' -> result + numbers[j + 1]
                '-' -> result - numbers[j + 1]
                else -> result
            }
        }

        return result
    }
}