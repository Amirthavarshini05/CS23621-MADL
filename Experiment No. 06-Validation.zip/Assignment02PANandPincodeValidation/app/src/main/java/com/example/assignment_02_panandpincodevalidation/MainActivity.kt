package com.example.assignment_02_panandpincodevalidation

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val etName = findViewById<EditText>(R.id.etName)
        val etID = findViewById<EditText>(R.id.etID)
        val btnValidate = findViewById<Button>(R.id.btnValidate)
        val tvResult = findViewById<TextView>(R.id.tvResult)

        btnValidate.setOnClickListener {

            val name = etName.text.toString().trim()
            val id = etID.text.toString().trim()

            // ✅ i) Check empty fields
            if (name.isEmpty() || id.isEmpty()) {
                tvResult.text = "Fields cannot be empty"
                return@setOnClickListener
            }

            // ✅ ii) Name should contain only alphabets
            if (!name.matches(Regex("^[a-zA-Z]+$"))) {
                tvResult.text = "Name must contain only alphabets"
                return@setOnClickListener
            }

            // ✅ iii) ID should be exactly 4 digits
            if (!id.matches(Regex("^\\d{4}$"))) {
                tvResult.text = "ID must be exactly 4 digits"
                return@setOnClickListener
            }

            // ✅ If all valid
            tvResult.text = "Validation Successful ✅"
        }
    }
}