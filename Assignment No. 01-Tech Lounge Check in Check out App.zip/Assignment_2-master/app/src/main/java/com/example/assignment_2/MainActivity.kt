package com.example.assignment_2

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private var count = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val countText = findViewById<TextView>(R.id.tvCount)
        val checkInBtn = findViewById<Button>(R.id.btnCheckIn)
        val checkOutBtn = findViewById<Button>(R.id.btnCheckOut)

        checkInBtn.setOnClickListener {
            count++
            countText.text = count.toString()
        }

        checkOutBtn.setOnClickListener {
            if (count > 0) {
                count--
                countText.text = count.toString()
            }
        }
    }
}